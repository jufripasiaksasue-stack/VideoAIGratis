from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import os

app = FastAPI(title="Video AI Gratis API", version="0.1.0")

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3)
    negative_prompt: str = ""
    duration_seconds: int = Field(default=30, ge=1, le=30)
    aspect_ratio: str = "9:16"
    image_uri: str = ""

@app.get("/")
def health():
    return {"status": "online", "app": "Video AI Gratis", "generator_configured": bool(os.getenv("VIDEO_GENERATOR_URL"))}

@app.post("/generate")
def generate(req: GenerateRequest):
    # Safety: this starter backend intentionally does not pretend to generate a video.
    # Connect an open-source video model worker here (e.g. a self-hosted GPU service).
    generator_url = os.getenv("VIDEO_GENERATOR_URL")
    if not generator_url:
        raise HTTPException(
            status_code=503,
            detail=(
                "Backend API aktif, tetapi model video belum dipasang. "
                "Hubungkan worker AI video open-source pada VIDEO_GENERATOR_URL. "
                "GPU inference mungkin memerlukan biaya; layanan gratis biasanya memiliki batas."
            )
        )
    raise HTTPException(
        status_code=501,
        detail="Adapter worker belum dibuat untuk endpoint model yang dipilih. Lihat README untuk langkah integrasi."
    )
