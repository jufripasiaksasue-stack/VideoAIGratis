# Backend Video AI Gratis

Backend ini baru menyediakan API dasar dan health check. **Belum menghasilkan video** sampai worker model AI disambungkan.

## Jalankan lokal
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Buka `http://127.0.0.1:8000/` untuk memeriksa status.

## Mengaktifkan generator
Pilih worker video open-source yang menerima prompt dan mengembalikan URL/file video, lalu buat adapter pada `main.py` untuk meneruskan:
- `prompt`
- `negative_prompt`
- `duration_seconds` (maksimum 30 pada kontrak aplikasi)
- `aspect_ratio`
- file foto referensi (fitur upload multipart perlu ditambahkan; saat ini aplikasi hanya mengirim URI lokal sebagai teks, yang tidak dapat dibaca server jarak jauh)

Model video berkualitas tinggi membutuhkan GPU dan memori besar. Hosting gratis dapat tidur, antre, membatasi durasi, atau tidak menyediakan GPU. Jangan memasukkan API key rahasia ke APK; simpan di backend.
