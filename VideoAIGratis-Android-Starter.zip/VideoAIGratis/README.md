# Video AI Gratis — proyek awal Android

Proyek ini adalah **starter APK** Android dengan UI Text-to-Video dan Image-to-Video, prompt utama, negative prompt, rasio video, target durasi 30 detik, serta workflow GitHub Actions untuk membangun APK.

## Penting: status fitur
- [x] Antarmuka Android dan input prompt
- [x] Pilih foto dari galeri (UI)
- [x] Pilih rasio 9:16 / 16:9 / 1:1
- [x] Tombol kirim permintaan ke backend
- [x] Build APK otomatis dengan GitHub Actions
- [ ] Mesin AI video belum disambungkan
- [ ] Upload file foto ke server belum diimplementasikan
- [ ] Unduh hasil video belum diimplementasikan

Jadi, proyek ini belum bisa disebut klon PixVerse yang sudah berfungsi penuh. Ini fondasi aplikasi yang dapat dibangun menjadi APK. Generator video 30 detik realistis memerlukan model AI dan komputasi GPU; tidak ada jaminan layanan gratis tanpa batas.

## Cara paling mudah dari HP Android
1. Unduh ZIP proyek ini dan ekstrak dengan ZArchiver.
2. Buka `github.com` di Chrome, masuk akun, lalu buat repository baru bernama `VideoAIGratis`.
3. Upload seluruh isi folder proyek ke repository (jangan upload file ZIP sebagai satu file).
4. Buka tab **Actions**, pilih workflow **Build Android APK**, lalu tekan **Run workflow**.
5. Tunggu sampai selesai. Buka hasil run, bagian **Artifacts**, lalu unduh `VideoAIGratis-debug-apk`.
6. Ekstrak artifact dan pasang `app-debug.apk`. Jika diminta, izinkan instalasi dari sumber tersebut.

## Jika upload dari HP sulit
Gunakan GitHub versi desktop di Chrome: menu titik tiga → centang **Situs desktop**. Upload file/folder melalui halaman repository atau aplikasi GitHub.

## Menjalankan backend uji
Lihat `backend/README.md`. Backend sekarang hanya memvalidasi koneksi dan memberi pesan bahwa model belum dikonfigurasi.

## Alamat backend
Di aplikasi, ubah kolom alamat server ke alamat backend yang benar. `http://10.0.2.2:8000` hanya alamat khusus emulator Android Studio, bukan alamat HP fisik. Untuk HP, gunakan alamat HTTPS server yang sudah Anda deploy.

## Teknologi
- Kotlin + Jetpack Compose
- Android Gradle Plugin
- FastAPI
- GitHub Actions

## Lisensi
Starter project untuk pembelajaran dan pengembangan. Nama "Video AI Gratis" bukan afiliasi dengan PixVerse.
