package id.videoaigratis.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter

private val Ink = Color(0xFF101326)
private val Purple = Color(0xFF7557FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VideoAiScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoAiScreen() {
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("wajah berubah, wajah ganda, tangan cacat, jari berlebih, blur, flicker, teks acak, watermark") }
    var ratio by remember { mutableStateOf("9:16") }
    var backend by remember { mutableStateOf("http://10.0.2.2:8000") }
    var status by remember { mutableStateOf("Siap membuat video. Hubungkan backend AI terlebih dahulu.") }
    var busy by remember { mutableStateOf(false) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { photoUri = it }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Ink, surface = Color(0xFF1B1E35),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Movie, null, tint = Purple, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("VIDEO AI GRATIS", fontSize = 21.sp, color = Color.White)
                        Text("Studio text-to-video & image-to-video", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF252044))) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Buat video sinematik", style = MaterialTheme.typography.titleLarge)
                        Text("Target proyek: video hingga 30 detik*", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Text("PROMPT UTAMA", color = Color(0xFFBDB4FF))
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(), minLines = 4,
                    placeholder = { Text("Contoh: seorang pria berjalan di tengah hujan malam, sinematik, realistis...") },
                    shape = RoundedCornerShape(14.dp)
                )
                Text("NEGATIVE PROMPT", color = Color(0xFFBDB4FF))
                OutlinedTextField(
                    value = negative, onValueChange = { negative = it },
                    modifier = Modifier.fillMaxWidth(), minLines = 2,
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (photoUri == null) "Pilih foto referensi (opsional)" else "Foto referensi sudah dipilih")
                }
                Text("RASIO VIDEO", color = Color(0xFFBDB4FF))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("9:16", "16:9", "1:1").forEach { item ->
                        FilterChip(selected = ratio == item, onClick = { ratio = item }, label = { Text(item) })
                    }
                }
                Text("ALAMAT SERVER AI", color = Color(0xFFBDB4FF))
                OutlinedTextField(
                    value = backend, onValueChange = { backend = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("https://alamat-server-anda") }
                )
                Button(
                    onClick = {
                        if (prompt.isBlank()) { status = "Isi prompt terlebih dahulu."; return@Button }
                        scope.launch {
                            busy = true
                            status = "Menghubungi backend..."
                            status = withContext(Dispatchers.IO) {
                                try {
                                    val endpoint = URL(backend.trimEnd('/') + "/generate")
                                    val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                                        requestMethod = "POST"
                                        connectTimeout = 15000
                                        readTimeout = 30000
                                        doOutput = true
                                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                                    }
                                    val safePrompt = prompt.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
                                    val safeNegative = negative.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ")
                                    val body = """{"prompt":"$safePrompt","negative_prompt":"$safeNegative","duration_seconds":30,"aspect_ratio":"$ratio","image_uri":"${photoUri?.toString() ?: ""}"}"""
                                    OutputStreamWriter(conn.outputStream).use { it.write(body) }
                                    val code = conn.responseCode
                                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                                    val response = stream?.bufferedReader()?.use { it.readText() } ?: "Tidak ada respons"
                                    conn.disconnect()
                                    if (code in 200..299) "Permintaan diterima server: $response"
                                    else "Server membalas HTTP $code: $response"
                                } catch (e: Exception) {
                                    "Gagal terhubung: ${e.localizedMessage}. Periksa alamat backend dan koneksi internet."
                                }
                            }
                            busy = false
                        }
                    },
                    enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    else {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("BUAT VIDEO 30 DETIK")
                    }
                }
                Text(status, color = Color(0xFFE2DEFF), fontSize = 13.sp)
                Text(
                    "*Durasi 30 detik adalah target aplikasi. Hasil nyata bergantung pada model AI dan server yang dipasang. APK ini adalah fondasi antarmuka; generator AI belum aktif sampai backend model dikonfigurasi.",
                    color = Color.LightGray, fontSize = 11.sp
                )
            }
        }
    }
}
